---
order: 0
english: Ruby X
---

<div style="text-align:center;background:#FBFBFB;margin:40px 0;">
  <img align="middle" width="600" src="https://os.alipayobjects.com/rmsportal/mgesTPFxodmIwpi.png">
</div>


RubyX
是一个致力于提升『用户』和『设计者』使用体验的前端设计语言。它模糊了产品经理、交互设计师、视觉设计师、前端工程师、开发工程师等角色边界，将进行 UE 设计和 UI 设计人员统称为『设计者』，利用统一的规范进行设计赋能，全面提高互联网金融前端体验和研发效率。

---

